#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

#define MAX_CLIENTS 5
#define MAX_RESPONSE_SIZE 1024

void error(const char *msg) {
    perror(msg);
    exit(1);
}

void send_response(int client_socket, const char *response) {
    send(client_socket, response, strlen(response), 0);
}

void handle_get_request(int client_socket, const char *filename) {
    char response[MAX_RESPONSE_SIZE];
    FILE *file = fopen(filename, "r");

    if (file != NULL) {
        fseek(file, 0, SEEK_END);
        long file_size = ftell(file);
        fseek(file, 0, SEEK_SET);

        sprintf(response, "HTTP/1.1 200 OK\r\nContent-Length: %ld\r\n\r\n", file_size);
        send_response(client_socket, response);

        while (!feof(file)) {
            size_t bytes_read;
            unsigned char buffer[MAX_RESPONSE_SIZE];
            bytes_read = fread(buffer, 1, sizeof(buffer), file);
            send(client_socket, buffer, bytes_read, 0);
        }
        fclose(file);
    } else {
        sprintf(response, "HTTP/1.1 404 Not Found\r\n\r\nFile not found.");
        send_response(client_socket, response);
    }
}

void client_handler(int newsockfd, int clientCount) {
    char buffer[255];

    // Read client name
    char clientName[20];
    snprintf(clientName, sizeof(clientName), "client%d", clientCount);

    printf("%s connected.\n", clientName);

    while (1) {
        // Read the client's command
        bzero(buffer, 255);
        if (read(newsockfd, buffer, sizeof(buffer)) < 0) {
            error("Error reading from socket");
        } else {
            printf("%s sent command: %s\n", clientName, buffer); // Debugging message
        }

        // Perform FTP operations based on the command
        if (strncmp(buffer, "GET", 3) == 0) {
            char filename[255]; // Declare a variable to store the filename
            bzero(filename, sizeof(filename)); // Initialize the filename buffer

            if (read(newsockfd, filename, sizeof(filename)) < 0) {
                error("Error reading file name from socket");
            } else {
                printf("%s sent file name: %s\n", clientName, filename); // Debugging message
            }

            handle_get_request(newsockfd,filename);

            // // Perform FTP operations based on the file name
            // if (strlen(filename) > 0) {
            //     printf("%s: File requested: %s\n", clientName, filename);

            //     // Now, you have the file name in the 'filename' variable.
            //     // You can use it for further processing (e.g., sending the file content).
            // } else {
            //     // Empty command
            //     const char *empty_msg = "Empty command. Please provide a file name.\n";
            //     write(newsockfd, empty_msg, strlen(empty_msg));
            // }



            
        
        
        }else if (strcmp(buffer, "PUT") == 0) {
            // Implement the PUT operation here
            printf("%s requested a PUT operation.\n", clientName);
        } else if (strcmp(buffer, "POST") == 0) {
            // Implement the POST operation here
            printf("%s requested a POST operation.\n", clientName);
        } else if (strcmp(buffer, "DELETE") == 0) {
            // Implement the DELETE operation here
            printf("%s requested a DELETE operation.\n", clientName);
        } else if (strcmp(buffer, "exit") == 0) {
            // Client requested to exit, close the connection
            printf("%s requested a EXIT operation.\n", clientName);
            break;
        } else {
            // Invalid command
            const char *invalid_msg = "Invalid command. Supported commands: GET, PUT, POST, DELETE, exit\n";
            write(newsockfd, invalid_msg, strlen(invalid_msg));
        }
   
    
    }
    close(newsockfd);
    printf("%s disconnected.\n", clientName);

}



int main(int argc, char *argv[]) {
    int sockfd, portno;
    socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr;
    int client_sockets[MAX_CLIENTS];

    if (argc < 2) {
        fprintf(stderr, "Usage: %s port\n", argv[0]);
        exit(1);
    }

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        error("Error while opening socket");
    }

    bzero((char *)&serv_addr, sizeof(serv_addr));
    portno = atoi(argv[1]);

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);

    if (bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        error("Binding error");
    }

    listen(sockfd, 5);
    clilen = sizeof(cli_addr);

    printf("Server listening on port %d...\n", portno);

    int clientCount = 0; // To keep track of connected clients

    while (clientCount < MAX_CLIENTS) {
        client_sockets[clientCount] = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);
        if (client_sockets[clientCount] < 0) {
            error("Error accepting connection");
        }

        // Fork a new process to handle each client
        int pid = fork();
        if (pid < 0) {
            error("Error forking process");
        } else if (pid == 0) {
            // In child process, handle the client
            client_handler(client_sockets[clientCount], clientCount + 1);
            exit(0); // Child process exits after handling the client
        }

        // In the parent process, continue accepting more clients
        clientCount++;
    }

    // Wait for all child processes to finish
    for (int i = 0; i < MAX_CLIENTS; i++) {
        wait(NULL);
    }

    close(sockfd);
    return 0;
}


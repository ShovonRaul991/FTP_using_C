#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

#define MAX_CLIENTS 5
#define MAX_RESPONSE_SIZE 1024
#define MAXLEN 1024

void error(const char *msg) {
    perror(msg);
    exit(1);
}

void send_response(int client_socket, const char *response) {
    send(client_socket, response, strlen(response), 0);
}

//Handle get request
void handleGetRequest(int client_socket) {
    char buffer[MAXLEN];
    
    // Receive client's request
    memset(buffer, 0, sizeof(buffer));
    ssize_t bytes_received = recv(client_socket, buffer, sizeof(buffer), 0);
    if (bytes_received <= 0) {
        perror("Receive error");
        exit(1);
    }

    // Parse the request
    char filename[MAXLEN];
    if (sscanf(buffer, "get %s", filename) != 1) {
        printf("Invalid request format. Use 'get filename.txt'.\n");
        exit(1);
    }

    // Check if the requested file exists
    FILE *file = fopen(filename, "rb");
    if (file == NULL) {
        printf("File not found: %s\n", filename);
        exit(1);
    }

    // Send the file name to the client
    send(client_socket, filename, strlen(filename), 0);

    // Send the file to the client
    while (1) {
        memset(buffer, 0, sizeof(buffer));
        size_t bytes_read = fread(buffer, 1, sizeof(buffer), file);
        if (bytes_read <= 0) {
            break; // End of file
        }
        
        send(client_socket, buffer, bytes_read, 0);
    }

    // Close the file
    fclose(file);
    printf("File sent to the client.\n");
}


void handle_put_request(int client_socket, const char *filename) {
    char response[MAX_RESPONSE_SIZE];

    // Open the file for writing, creating it if it doesn't exist
    FILE *file = fopen(filename, "w");

    if (file != NULL) {
        // Read data from the client and write it to the file
        char buffer[MAX_RESPONSE_SIZE];
        ssize_t bytes_received;

        while ((bytes_received = recv(client_socket, buffer, sizeof(buffer), 0)) > 0) {
            fwrite(buffer, 1, bytes_received, file);
        }

        fclose(file);

        // Send a success response to the client
        sprintf(response, "HTTP/1.1 200 OK\r\nContent-Length: %ld\r\n\r\nFile updated successfully.", ftell(file));
        send_response(client_socket, response);
    } else {
        // Send an error response to the client
        sprintf(response, "HTTP/1.1 500 Internal Server Error\r\n\r\nError writing to file.");
        send_response(client_socket, response);
    }
}

void handle_post_request(int client_socket, const char *filename) {
    char response[MAX_RESPONSE_SIZE];

    // Open the file for appending, creating it if it doesn't exist
    FILE *file = fopen(filename, "a");

    if (file != NULL) {
        // Read data from the client and append it to the file
        char buffer[MAX_RESPONSE_SIZE];
        ssize_t bytes_received;

        while ((bytes_received = recv(client_socket, buffer, sizeof(buffer), 0)) > 0) {
            fwrite(buffer, 1, bytes_received, file);
        }

        fclose(file);

        // Send a success response to the client
        sprintf(response, "HTTP/1.1 200 OK\r\nContent-Length: %ld\r\n\r\nData updated successfully.", ftell(file));
        send_response(client_socket, response);
    } else {
        // Send an error response to the client
        sprintf(response, "HTTP/1.1 500 Internal Server Error\r\n\r\nError writing to file.");
        send_response(client_socket, response);
    }
}

void handle_delete_request(int client_socket, const char *filename) {
    char response[MAX_RESPONSE_SIZE];

    // Attempt to delete the specified file
    if (remove(filename) == 0) {
        printf("File %s deleted.\n", filename);
        sprintf(response, "HTTP/1.1 200 OK\r\n\r\nFile deleted successfully.");
        send_response(client_socket, response);
    } else {
        perror("Error deleting file");
        sprintf(response, "HTTP/1.1 500 Internal Server Error\r\n\r\nError deleting file.");
        send_response(client_socket, response);
    }
}

void client_handler(int newsockfd, int clientCount) {
    char buffer[255];

    // Read client name
    char clientName[20];
    snprintf(clientName, sizeof(clientName), "client%d", clientCount);

    printf("%s connected.\n", clientName);

    while (1) {
        // Read the client's command
        bzero(buffer, sizeof(buffer));
        if (read(newsockfd, buffer, sizeof(buffer)) < 0) {
            error("Error reading from socket");
        } else {
            printf("%s sent command: %s\n", clientName, buffer); // Debugging message
        }

        // Extract the command and filename from the client's message
        char command[5];
        char filename[255];
        sscanf(buffer, "%s %s", command, filename);

        // Perform FTP operations based on the command
        if (strcmp(command, "GET") == 0) {
            handleGetRequest(newsockfd);
        } else if (strcmp(command, "PUT") == 0) {
            handle_put_request(newsockfd, filename);
        } else if (strcmp(command, "POST") == 0) {
            handle_post_request(newsockfd, filename);
        } else if (strcmp(command, "DELETE") == 0) {
            handle_delete_request(newsockfd, filename);
        } else if (strcmp(command, "exit") == 0) {
            // Client requested to exit, close the connection
            printf("%s requested an EXIT operation.\n", clientName);
            break;
        } else {
            // Invalid command
            const char *invalid_msg = "Invalid command. Supported commands: GET, PUT, POST, DELETE, exit\n";
            write(newsockfd, invalid_msg, strlen(invalid_msg));
        }
    }

    close(newsockfd);
    printf("%s disconnected.\n", clientName);
}

int main(int argc, char *argv[]) {
    int sockfd, portno;
    socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr;
    int client_sockets[MAX_CLIENTS];

    if (argc < 2) {
        fprintf(stderr, "Usage: %s port\n", argv[0]);
        exit(1);
    }

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        error("Error while opening socket");
    }

    bzero((char *)&serv_addr, sizeof(serv_addr));
    portno = atoi(argv[1]);

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);

    if (bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        error("Binding error");
    }

    listen(sockfd, 5);
    clilen = sizeof(cli_addr);

    printf("Server listening on port %d...\n", portno);

    int clientCount = 0; // To keep track of connected clients

    while (clientCount < MAX_CLIENTS) {
        client_sockets[clientCount] = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);
        if (client_sockets[clientCount] < 0) {
            error("Error accepting connection");
        }

        // Fork a new process to handle each client
        int pid = fork();
        if (pid < 0) {
            error("Error forking process");
        } else if (pid == 0) {
            // In child process, handle the client
            client_handler(client_sockets[clientCount], clientCount + 1);
            exit(0); // Child process exits after handling the client
        }

        // In the parent process, continue accepting more clients
        clientCount++;
    }

    // Wait for all child processes to finish
    for (int i = 0; i < MAX_CLIENTS; i++) {
        wait(NULL);
    }

    close(sockfd);
    return 0;
}

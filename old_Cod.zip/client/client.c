#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>

#define MAX_RESPONSE_SIZE 1024

void error(const char *msg) {
    perror(msg);
    exit(1);
}

void receiveFile(int sockfd, const char *filename) {
    char response[MAX_RESPONSE_SIZE];
    FILE *file = fopen(filename, "wb");

    if (file != NULL) {
        ssize_t bytes_received;
        while ((bytes_received = recv(sockfd, response, sizeof(response), 0)) > 0) {
            fwrite(response, 1, bytes_received, file);
        }

        fclose(file);
        printf("File '%s' downloaded successfully.\n", filename);
    } else {
        perror("Error opening file");
    }
}

int main(int argc, char *argv[]) {
    // ... (other code)

    while (1) {
        // ... (other code)

        if (strcmp(buffer, "GET") == 0) {
            printf("Enter file name: ");
            fgets(buffer, sizeof(buffer), stdin);

            // Remove trailing newline character
            len = strlen(buffer);
            if (len > 0 && buffer[len - 1] == '\n') {
                buffer[len - 1] = '\0';
            }

            // Send the file name to the server
            if (write(sockfd, buffer, strlen(buffer)) < 0) {
                error("Error sending file name to server");
            }

            receiveFile(sockfd, "Received.txt");
        } else if (strcmp(buffer, "PUT") == 0) {
            // Implement the PUT operation here
            printf("This is a PUT COMMAND\n");
        } else if (strcmp(buffer, "POST") == 0) {
            // Implement the POST operation here
            printf("This is a POST COMMAND\n");
        } else if (strcmp(buffer, "DELETE") == 0) {
            // Implement the DELETE operation here
            printf("This is a DELETE COMMAND\n");
        } else {
            printf("Invalid command. Supported commands: GET, PUT, POST, DELETE, exit\n");
        }
    }

    close(sockfd);
    return 0;
}

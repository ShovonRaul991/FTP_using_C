#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

#define MAX_RESPONSE_SIZE 1024

void error(const char *msg) {
    perror(msg);
    exit(1);
}

void send_request(int sockfd, const char *request) {
    send(sockfd, request, strlen(request), 0);
}

void receive_response(int sockfd) {
    char response[MAX_RESPONSE_SIZE];
    ssize_t bytes_received;

    while ((bytes_received = recv(sockfd, response, sizeof(response), 0)) > 0) {
        fwrite(response, 1, bytes_received, stdout);
    }
}

int main(int argc, char *argv[]) {
    int sockfd, portno;
    struct sockaddr_in serv_addr;

    if (argc < 3) {
        fprintf(stderr, "Usage: %s hostname port\n", argv[0]);
        exit(1);
    }

    portno = atoi(argv[2]);

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        error("Error while opening socket");
    }

    bzero((char *)&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(portno);
    serv_addr.sin_addr.s_addr = inet_addr(argv[1]);

    if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        error("Error connecting to server");
    }

    char command[10];
    char filename[255];

    while (1) {
        printf("Enter command (GET, PUT, POST, DELETE, exit): ");
        scanf("%s", command);

        if (strcmp(command, "exit") == 0) {
            // Exit the loop and close the connection
            break;
        } else if (strcmp(command, "GET") == 0 || strcmp(command, "PUT") == 0 || strcmp(command, "POST") == 0 || strcmp(command, "DELETE") == 0) {
            // If it's a valid command, prompt for a filename
            printf("Enter filename: ");
            scanf("%s", filename);

            // Send the command and filename to the server
            char request[MAX_RESPONSE_SIZE];
            snprintf(request, sizeof(request), "%s %s\n", command, filename);
            send_request(sockfd, request);

            // Receive and print the response from the server
            receive_response(sockfd);
            
        } else {
            printf("Invalid command. Supported commands: GET, PUT, POST, DELETE, exit\n");
        }
    }

    close(sockfd);
    return 0;
}
